int a=1;
a+b=c;